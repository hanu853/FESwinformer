# FESwinFormer

**A Foreground Feature Enhancement-Based Swin Transformer for Frame-Level Surveillance Video Anomaly Classification**

FESwinFormer classifies individual surveillance-video frames as normal or as one of several anomalous activities. It targets crowded scenes where the foreground actor and the background have similar colours. A hierarchical Swin Transformer backbone is followed by three modules:

- **Foreground Feature Enhancement Block (FFEB):** an Improved Multi-Head Self-Attention (MHSA) branch with dual forward/reverse affinity, a Shifted Window-Based MHSA (SW-MSA) branch and a Global Context Refinement branch.
- **Multi-Scale Convolution Block (MSCB):** parallel 1×1, 3×3 and 5×5 convolutions.
- **Channel Attention Module (CAM):** squeeze-and-excitation style channel re-weighting, r = 16.

The model is evaluated at the frame level on **UCF-Crime** (14 classes: 13 anomaly classes + Normal) and **RLVS** (binary: violence / non-violence).

---

## Repository structure

```
├── FESwinFormer_UCF_Crime.ipynb   # data loading, model, training, evaluation, 10-fold CV and statistics (UCF-Crime)
├── feswinformer_model.py          # standalone FESwinFormer implementation (same code as the model cell in the notebook)
├── requirements.txt
└── README.md
```

---

## Architecture

```mermaid
flowchart LR
    A[Frame] --> B[Resize 256×256<br/>Z-score norm]
    B --> C[Patch Partition 4×4<br/>Linear Embedding C=128]
    C --> D[Swin Stage 1<br/>×2 · 64×64×128]
    D --> E[Swin Stage 2<br/>×2 · 32×32×256]
    E --> F[Swin Stage 3<br/>×6 · 16×16×512]
    F --> G[Swin Stage 4<br/>×2 · 8×8×1024]
    G --> H1[Improved MHSA]
    G --> H2[SW-MSA]
    G --> H3[Global Context]
    H1 --> I[F1 = Linear Concat]
    H2 --> I
    I --> J[X_FFEB = Linear Concat]
    H3 --> J
    J --> K[MSCB 1×1 / 3×3 / 5×5<br/>8×8×192]
    K --> L[Channel Attention<br/>r = 16]
    L --> M[GAP → Dense 256 → Dropout 0.3]
    M --> N[Softmax 14 · UCF-Crime<br/>Sigmoid 1 · RLVS]
```

### Layer-wise configuration

| Module | Operation | Output size |
|---|---|---|
| Preprocessing | Resize to 256 × 256 × 3; channel-wise Z-score normalisation (training-set μ, σ) | 256 × 256 × 3 |
| Patch Partition + Linear Embedding | Conv2D(128, kernel 4 × 4, stride 4) + LayerNorm | 64 × 64 × 128 |
| Stage 1 | 2 Swin blocks (W-MSA → SW-MSA), 4 heads | 64 × 64 × 128 |
| Patch Merging | Downsample ×2, double channels | 32 × 32 × 256 |
| Stage 2 | 2 Swin blocks, 8 heads | 32 × 32 × 256 |
| Patch Merging | Downsample ×2, double channels | 16 × 16 × 512 |
| Stage 3 | 6 Swin blocks, 16 heads | 16 × 16 × 512 |
| Patch Merging | Downsample ×2, double channels | 8 × 8 × 1024 |
| Stage 4 | 2 Swin blocks, 32 heads | 8 × 8 × 1024 |
| FFEB – Improved MHSA | f, g, k, p, l projections; β = Softmax(fgᵀ/√d), β′ = Softmax(kpᵀ/√d), β̂ = Softmax(β + β′); X_MHSA = γ·Concat(β̂l) + X (h = 32, d = 32) | N × C (64 × 1024) |
| FFEB – SW-MSA | 7 × 7 windows (padding removed after attention), cyclic shift and reverse shift | N × C |
| FFEB – Global Context | GAP → K_c, V_c; Q_c from X; Softmax(Q_cK_cᵀ/√d)·V_c broadcast; LayerNorm(X_global + X) | N × C |
| FFEB – Fusion | F1 = Linear(Concat(X_MHSA, X_SW-MSA)); X_FFEB = Linear(Concat(F1, X_Global)) | N × C → 8 × 8 × 1024 |
| MSCB | Conv 1 × 1, 3 × 3, 5 × 5 (64 filters each, ReLU, stride 1, same padding) → Concat | 8 × 8 × 192 |
| Channel Attention | GAP → Dense(12, ReLU) → Dense(192, Sigmoid) → reshape → Fusion ⊙ A | 8 × 8 × 192 |
| Head | GAP → Dense(256, ReLU) → Dropout(0.3) | 256 |
| Output | Dense(14, Softmax) for UCF-Crime / Dense(1, Sigmoid) for RLVS | 14 / 1 |

Trainable parameters of the implementation: **68,034,995** (UCF-Crime head).

---

## Requirements

Experiments in the paper used Python 3.12, TensorFlow 2.20.0 and Keras 3.13.2, on an Intel Core i7-12700K with an NVIDIA GeForce RTX 3050 (8 GB).

```bash
pip install -r requirements.txt
```

---

## Datasets

| Dataset | Content | Classes | Split used in the paper |
|---|---|---|---|
| [UCF-Crime](https://www.crcv.ucf.edu/projects/real-world/) | 1,900 untrimmed real-world surveillance videos (128 h) | 14 (Abuse, Arrest, Arson, Assault, Burglary, Explosion, Fighting, Normal, Road Accident, Robbery, Shooting, Shoplifting, Stealing, Vandalism) | Official predefined train/test split |
| [RLVS](https://www.kaggle.com/datasets/mohamedmustafa/real-life-violence-situations-dataset) | 2,000 clips (1,000 violent / 1,000 non-violent) | 2 | 70 : 10 : 20 (train : val : test), stratified |

**Preprocessing in the paper:**
- Every 16th frame of each video is extracted with OpenCV (frame_interval = 16).
- Frames are resized to 256 × 256 and Z-score normalised per channel.
- No data augmentation is used.
- Splits are made at the video level, so frames from one video never appear in two partitions.

The notebook reads the frame-level Kaggle version of UCF-Crime (`/kaggle/input/datasets/odins0n/ucf-crime-dataset/{Train,Test}`, 64 × 64 PNG frames). The model resizes these frames to 256 × 256 internally.

---

## Usage

### Build the model

```python
from feswinformer_model import create_proposed_model

# UCF-Crime: 14 classes, softmax + categorical cross-entropy (one-hot labels)
model = create_proposed_model(input_shape=(64, 64, 3), num_classes=14)

# RLVS: single sigmoid unit + binary cross-entropy (labels 0 / 1)
model_rlvs = create_proposed_model(input_shape=(224, 224, 3), num_classes=1)

model.fit(x_train, y_train, batch_size=16, epochs=50, validation_data=(x_val, y_val))
```

`create_proposed_model` returns a compiled model (Adam, learning rate 0.00017). The model's `fit` also does two things for you:

1. It computes the channel-wise Z-score statistics (μ, σ) from the training array passed to the first `fit` call. Each new model (for example, one per cross-validation fold) therefore uses statistics from its own training portion only.
2. It applies cosine annealing to the learning rate over the requested number of epochs.

### Notebook

Run `FESwinFormer_UCF_Crime.ipynb` from top to bottom on Kaggle (GPU):

1. Dataset exploration and class distribution plots.
2. Frame loading, normalisation and one-hot encoding.
3. FESwinFormer model definition and summary.
4. Training, test evaluation, classification report, confusion matrix, ROC curves and prediction samples.
5. 10-fold cross-validation (`KFold(n_splits=10, shuffle=True, random_state=42)`): a fresh model is created for each fold, followed by the per-fold classification report and confusion matrix.
6. Statistical analysis: mean, sample standard deviation, standard error, critical t-value (df = 9) and 95 % confidence interval, plus the fold-accuracy plot.

---

## Hyperparameters – FESwinFormer

| Parameter | Value |
|---|---|
| Input resolution | 256 × 256 × 3 |
| Frame sampling | Every 16th frame |
| Patch size / embedding dimension | 4 × 4 / 128 |
| Swin depths | [2, 2, 6, 2] |
| Attention heads (Stages 1–4) | 4 / 8 / 16 / 32 (head dimension d = 32) |
| Window size (M) | 7 × 7 |
| MLP ratio | 4 |
| FFEB heads (Improved MHSA, SW-MSA) | 32 |
| MSCB filters per branch | 64 (1 × 1, 3 × 3, 5 × 5) |
| Channel-attention reduction ratio (r) | 16 |
| Dense units / Dropout | 256 / 0.3 |
| Optimizer | Adam |
| Learning rate | 0.00017 |
| Learning-rate scheduler | Cosine annealing |
| Batch size | 16 |
| Epochs | 50 |
| Loss | Categorical cross-entropy (UCF-Crime) / Binary cross-entropy (RLVS) |
| Output activation | Softmax (UCF-Crime) / Sigmoid (RLVS) |
| Repeated runs (primary evaluation) | 10, seeds 1, 2, 3, 7, 12, 17, 21, 37, 42, 51 |
| Cross-validation (secondary evaluation) | 10-fold |

## Hyperparameters – Baseline models

All baselines use the same training protocol as FESwinFormer:

| Setting (common to all baselines) | Value |
|---|---|
| Input resolution | 256 × 256 × 3 (same sampled frames as FESwinFormer) |
| Optimizer | Adam |
| Learning rate | 0.00017 |
| Learning-rate scheduler | Cosine annealing |
| Batch size | 16 |
| Epochs | 50 |
| Loss | Categorical cross-entropy (UCF-Crime) / Binary cross-entropy (RLVS) |
| Output layer | Dense(14, Softmax) (UCF-Crime) / Dense(1, Sigmoid) (RLVS) |
| Data augmentation | None |
| Evaluation | 10-fold cross-validation, same folds as FESwinFormer |

| Model | Architecture family | Key architecture settings | Parameters (K) |
|---|---|---|---|
| SE-ResNet | CNN | Bottleneck residual blocks with Squeeze-and-Excitation, reduction ratio r = 16 | 92,416.35 |
| ConvNeXt | Modernised CNN | 4 × 4 stride-4 patchify stem, 7 × 7 depthwise convolutions, inverted bottleneck (expansion 4), LayerNorm, GELU, 4 stages | 84,732.18 |
| CrossViT | Dual-branch ViT | Small-patch and large-patch branches, cross-attention fusion via CLS tokens | 81,594.62 |
| CoAtNet | Hybrid conv + attention | C-C-T-T layout: MBConv stages followed by relative-attention Transformer stages | 76,328.47 |
| MaxViT | Hybrid conv + attention | MBConv + block (window) attention + grid attention, window / grid size 7 × 7 | 73,846.29 |
| Efficient Swin Transformer | Hierarchical ViT | Shifted-window self-attention, window size 7 × 7, patch merging between stages | 71,254.83 |
| **FESwinFormer** | Hierarchical ViT + FFEB / MSCB / CAM | Swin [2, 2, 6, 2], C = 128, window 7 × 7, FFEB (32 heads), MSCB (3 × 64), CAM (r = 16) | 68,001.94 |

---

## Results – 10-fold cross-validation accuracy (%)

| Dataset | Run | SE-ResNet | ConvNeXt | CrossViT | CoAtNet | MaxViT | Efficient Swin Transformer | FESwinFormer |
|---|---|---|---|---|---|---|---|---|
| UCF-Crime | 1 | 90.32 | 91.81 | 92.81 | 93.87 | 94.87 | 95.28 | 95.09 |
| | 2 | 93.58 | 94.87 | 95.61 | 96.31 | 96.99 | 97.19 | 97.14 |
| | 3 | 91.27 | 92.71 | 93.64 | 94.59 | 95.50 | 95.84 | 95.95 |
| | 4 | 88.97 | 90.54 | 91.66 | 92.87 | 94.00 | 94.49 | 98.12 |
| | 5 | 94.73 | 95.96 | 96.60 | 97.17 | 97.74 | 97.87 | 97.38 |
| | 6 | 92.04 | 93.43 | 94.29 | 95.16 | 95.99 | 96.29 | 97.57 |
| | 7 | 93.96 | 95.23 | 95.94 | 96.60 | 97.24 | 97.42 | 98.46 |
| | 8 | 90.70 | 92.17 | 93.14 | 94.16 | 95.12 | 95.50 | 96.07 |
| | 9 | 94.15 | 95.41 | 96.10 | 96.74 | 97.37 | 97.53 | 98.10 |
| | 10 | 88.78 | 90.36 | 91.50 | 92.72 | 93.87 | 94.38 | 95.35 |
| | **Mean** | 91.85 ± 2.18 | 93.25 ± 2.05 | 94.13 ± 1.87 | 95.02 ± 1.63 | 95.87 ± 1.42 | 96.18 ± 1.28 | **96.92 ± 1.2178** |
| RLVS | 1 | 81.76 | 83.11 | 84.52 | 85.71 | 86.81 | 87.73 | 87.95 |
| | 2 | 83.66 | 84.79 | 85.94 | 86.94 | 87.92 | 88.75 | 88.16 |
| | 3 | 82.31 | 83.60 | 84.94 | 86.07 | 87.13 | 88.03 | 88.23 |
| | 4 | 80.97 | 82.42 | 83.94 | 85.21 | 86.35 | 87.31 | 89.24 |
| | 5 | 84.33 | 85.38 | 86.44 | 87.37 | 88.31 | 89.11 | 89.41 |
| | 6 | 82.76 | 84.00 | 85.27 | 86.36 | 87.40 | 88.27 | 88.30 |
| | 7 | 83.88 | 84.98 | 86.11 | 87.08 | 88.05 | 88.87 | 89.41 |
| | 8 | 81.98 | 83.31 | 84.69 | 85.86 | 86.94 | 87.85 | 88.34 |
| | 9 | 83.99 | 85.08 | 86.19 | 87.16 | 88.11 | 88.93 | 87.57 |
| | 10 | 80.86 | 82.32 | 83.85 | 85.14 | 86.29 | 87.25 | 88.51 |
| | **Mean** | 82.65 ± 1.27 | 83.90 ± 1.12 | 85.19 ± 0.95 | 86.29 ± 0.82 | 87.33 ± 0.74 | 88.21 ± 0.68 | **88.51 ± 0.6323** |

Values are mean ± sample standard deviation over the 10 folds.

### FESwinFormer – statistical summary (10-fold)

| Dataset | Mean accuracy (%) | Std deviation | Std error | Critical t (df = 9) | 95 % CI |
|---|---|---|---|---|---|
| UCF-Crime | 96.92 | 1.2178 | 0.3851 | 2.2622 | [96.05, 97.80] |
| RLVS | 88.51 | 0.6323 | 0.1999 | 2.2622 | [88.05, 88.96] |

---

## Limitations

FESwinFormer classifies each frame on its own. It does not model temporal dependencies across consecutive frames, and it does not aggregate predictions to the video level.
