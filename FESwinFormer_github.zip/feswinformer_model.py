# ==============================================================================
# FESwinFormer: A Foreground Feature Enhancement-Based Swin Transformer for
# Frame-Level Surveillance Video Anomaly Classification
# ------------------------------------------------------------------------------
# Implementation of the proposed technique (Section 2, Tables 1 and 2):
#   Input frame -> Resize 256x256 -> channel-wise Z-score normalisation (Eq. 1)
#   -> Patch Partition + Linear Embedding (Conv2D 128, 4x4, stride 4)
#   -> Hierarchical Swin Transformer backbone, depths [2, 2, 6, 2],
#      C = 128 / 256 / 512 / 1024, heads 4 / 8 / 16 / 32 (d = 32), window 7x7
#   -> Foreground Feature Enhancement Block (FFEB)              (Eq. 2-13)
#        Branch 1 : Improved MHSA (dual forward/reverse affinity)
#        Branch 2 : Shifted Window-Based MHSA (SW-MSA)
#        Branch C : Global Context Refinement (pooled K/V, residual + LN)
#        Fusion   : F1 = Linear(Concat(MHSA, SW-MSA));
#                   X_ffeb = Linear(Concat(F1, Global))
#   -> Multi-Scale Convolution Block (MSCB, 1x1 / 3x3 / 5x5, 64 each) (Eq. 14-17)
#   -> Channel Attention Module (CAM, r = 16 -> 192/16 = 12 units)   (Eq. 18-21)
#   -> GAP -> Dense(256, ReLU) -> Dropout(0.3)                       (Eq. 22-23)
#   -> Dense(14, Softmax) for UCF-Crime | Dense(1, Sigmoid) for RLVS  (Eq. 24-25)
# Optimiser: Adam, learning rate 0.00017, cosine annealing (Table 1).
# ==============================================================================

import math

import numpy as np
import tensorflow as tf
import keras
from keras import layers, ops

# ------------------------------------------------------------------------------
# Configuration (Table 1 and Table 2)
# ------------------------------------------------------------------------------
IMG_SIZE = 256                 # every frame is resized to 256 x 256 x 3
PATCH_SIZE = 4                 # non-overlapping 4 x 4 patches -> 64 x 64 grid
EMBED_DIM = 128                # C (Stage 1)
DEPTHS = [2, 2, 6, 2]          # Swin blocks per stage
NUM_HEADS = [4, 8, 16, 32]     # constant head dimension d = 32
WINDOW_SIZE = 7                # SW-MSA window size M = 7 x 7
MLP_RATIO = 4.0
FFEB_HEADS = 32                # Improved-MHSA / SW-MSA heads on the 8x8x1024 map
MSCB_FILTERS = 64              # filters per MSCB branch (3 branches -> 192)
CA_REDUCTION = 16              # channel-attention reduction ratio r
DENSE_UNITS = 256
DROPOUT_RATE = 0.3
LEARNING_RATE = 0.00017        # Adam + cosine annealing
PAPER_EPOCHS = 50
PAPER_BATCH_SIZE = 16
LN_EPS = 1e-5


# ==============================================================================
# Preprocessing: channel-wise Z-score normalisation (Eq. 1)
# ==============================================================================
class ChannelZScore(layers.Layer):
    """F' = (F - mu) / sigma with per-channel mu / sigma of the TRAINING data.

    The statistics are stored as non-trainable weights. They are computed
    automatically from the arrays passed to the first ``model.fit`` call
    (see ``FESwinFormer.fit``), i.e. from the training portion only, and are
    therefore recomputed independently for every fold of the 10-fold protocol.
    """

    def build(self, input_shape):
        ch = input_shape[-1]
        self.mean = self.add_weight(name="mean", shape=(ch,),
                                    initializer="zeros", trainable=False)
        self.std = self.add_weight(name="std", shape=(ch,),
                                   initializer="ones", trainable=False)

    def set_statistics(self, mean, std):
        self.mean.assign(np.asarray(mean, dtype="float32"))
        self.std.assign(np.maximum(np.asarray(std, dtype="float32"), 1e-6))

    def call(self, x):
        return (x - self.mean) / self.std


def channel_statistics(x, chunk=2048):
    """Per-channel mean / std of an (N, H, W, C) array, computed in chunks."""
    x = np.asarray(x)
    n_pix = 0
    s1 = np.zeros(x.shape[-1], dtype="float64")
    s2 = np.zeros(x.shape[-1], dtype="float64")
    for i in range(0, len(x), chunk):
        b = x[i:i + chunk].astype("float64").reshape(-1, x.shape[-1])
        s1 += b.sum(axis=0)
        s2 += (b ** 2).sum(axis=0)
        n_pix += b.shape[0]
    mean = s1 / n_pix
    std = np.sqrt(np.maximum(s2 / n_pix - mean ** 2, 0.0))
    return mean, std


# ==============================================================================
# Swin Transformer components
# ==============================================================================
def _relative_position_index(ws):
    coords = np.stack(np.meshgrid(np.arange(ws), np.arange(ws), indexing="ij"))
    coords = coords.reshape(2, -1)
    rel = (coords[:, :, None] - coords[:, None, :]).transpose(1, 2, 0)
    rel[:, :, 0] += ws - 1
    rel[:, :, 1] += ws - 1
    rel[:, :, 0] *= 2 * ws - 1
    return rel.sum(-1).reshape(-1).astype("int32")


def _shift_padding_mask(H, W, ws, shift):
    """Additive attention mask (nW, ws*ws, ws*ws) for padded / shifted windows.

    When H or W is not a multiple of the 7x7 window, the map is zero-padded,
    padded keys are masked out, and the padding is removed after attention.
    Returns None when neither padding nor shifting is needed.
    """
    Hp = int(math.ceil(H / ws)) * ws
    Wp = int(math.ceil(W / ws)) * ws
    if shift == 0 and Hp == H and Wp == W:
        return None

    region = np.zeros((Hp, Wp), dtype="int32")
    if shift > 0:
        cnt = 0
        for hs in (slice(0, -ws), slice(-ws, -shift), slice(-shift, None)):
            for wsl in (slice(0, -ws), slice(-ws, -shift), slice(-shift, None)):
                region[hs, wsl] = cnt
                cnt += 1

    pad = np.zeros((Hp, Wp), dtype=bool)
    pad[H:, :] = True
    pad[:, W:] = True
    if shift > 0:
        pad = np.roll(pad, shift=(-shift, -shift), axis=(0, 1))

    def to_windows(a):
        a = a.reshape(Hp // ws, ws, Wp // ws, ws).transpose(0, 2, 1, 3)
        return a.reshape(-1, ws * ws)

    region_w = to_windows(region)
    pad_w = to_windows(pad)
    mask = np.where(region_w[:, :, None] != region_w[:, None, :], -100.0, 0.0)
    mask = mask + np.where(pad_w[:, None, :], -100.0, 0.0)
    return mask.astype("float32")


class WindowAttention(layers.Layer):
    """Window-based multi-head self-attention, Attention = Softmax(QK^T/sqrt(d))V
    (Eq. 6), with a learnable relative position bias."""

    def __init__(self, dim, num_heads, window_size, **kwargs):
        super().__init__(**kwargs)
        self.dim = dim
        self.num_heads = num_heads
        self.window_size = window_size
        self.head_dim = dim // num_heads
        self.scale = self.head_dim ** -0.5
        self.qkv = layers.Dense(dim * 3, name="qkv")
        self.proj = layers.Dense(dim, name="proj")
        self.rel_index = _relative_position_index(window_size)

    def build(self, input_shape):
        ws = self.window_size
        self.rel_bias_table = self.add_weight(
            name="relative_position_bias_table",
            shape=((2 * ws - 1) ** 2, self.num_heads),
            initializer=keras.initializers.TruncatedNormal(stddev=0.02),
            trainable=True)
        self.qkv.build(input_shape)
        self.proj.build(input_shape)

    def call(self, x, attn_mask=None):
        N = self.window_size * self.window_size
        h, d = self.num_heads, self.head_dim

        qkv = ops.reshape(self.qkv(x), (-1, N, 3, h, d))
        qkv = ops.transpose(qkv, (2, 0, 3, 1, 4))
        q, k, v = qkv[0] * self.scale, qkv[1], qkv[2]

        attn = ops.matmul(q, ops.transpose(k, (0, 1, 3, 2)))       # (B*nW, h, N, N)
        bias = ops.take(self.rel_bias_table, self.rel_index, axis=0)
        bias = ops.transpose(ops.reshape(bias, (N, N, h)), (2, 0, 1))
        attn = attn + ops.expand_dims(bias, 0)

        if attn_mask is not None:
            nW = attn_mask.shape[0]
            attn = ops.reshape(attn, (-1, nW, h, N, N))
            attn = attn + attn_mask[None, :, None, :, :]
            attn = ops.reshape(attn, (-1, h, N, N))

        attn = ops.softmax(attn, axis=-1)
        out = ops.matmul(attn, v)                                  # (B*nW, h, N, d)
        out = ops.reshape(ops.transpose(out, (0, 2, 1, 3)), (-1, N, self.dim))
        return self.proj(out)


class ShiftedWindowMSA(layers.Layer):
    """Pad -> (cyclic shift) -> window partition -> window attention ->
    window reverse -> (reverse shift) -> remove padding.

    shift_size = 0 gives W-MSA, shift_size = M // 2 gives SW-MSA."""

    def __init__(self, dim, num_heads, window_size=WINDOW_SIZE, shift_size=0,
                 **kwargs):
        super().__init__(**kwargs)
        self.dim = dim
        self.window_size = window_size
        self.shift_size = shift_size
        self.attn = WindowAttention(dim, num_heads, window_size, name="attn")

    def build(self, input_shape):
        H, W = int(input_shape[1]), int(input_shape[2])
        ws = self.window_size
        self.H, self.W = H, W
        self.Hp = int(math.ceil(H / ws)) * ws
        self.Wp = int(math.ceil(W / ws)) * ws
        mask = _shift_padding_mask(H, W, ws, self.shift_size)
        self.attn_mask = mask                    # numpy constant (or None)
        self.attn.build((None, ws * ws, self.dim))

    def call(self, x):
        ws, s = self.window_size, self.shift_size
        H, W, Hp, Wp, C = self.H, self.W, self.Hp, self.Wp, self.dim

        if Hp != H or Wp != W:
            x = ops.pad(x, [[0, 0], [0, Hp - H], [0, Wp - W], [0, 0]])
        if s > 0:
            x = ops.roll(x, shift=(-s, -s), axis=(1, 2))

        # window partition -> (B * nW, ws*ws, C)
        x = ops.reshape(x, (-1, Hp // ws, ws, Wp // ws, ws, C))
        x = ops.transpose(x, (0, 1, 3, 2, 4, 5))
        x = ops.reshape(x, (-1, ws * ws, C))

        mask = None if self.attn_mask is None else ops.convert_to_tensor(self.attn_mask)
        x = self.attn(x, attn_mask=mask)

        # window reverse -> (B, Hp, Wp, C)
        x = ops.reshape(x, (-1, Hp // ws, Wp // ws, ws, ws, C))
        x = ops.transpose(x, (0, 1, 3, 2, 4, 5))
        x = ops.reshape(x, (-1, Hp, Wp, C))

        if s > 0:
            x = ops.roll(x, shift=(s, s), axis=(1, 2))
        if Hp != H or Wp != W:
            x = x[:, :H, :W, :]
        return x


class SwinTransformerBlock(layers.Layer):
    """LN -> (S)W-MSA -> residual -> LN -> MLP -> residual."""

    def __init__(self, dim, num_heads, window_size=WINDOW_SIZE, shift_size=0,
                 mlp_ratio=MLP_RATIO, **kwargs):
        super().__init__(**kwargs)
        self.norm1 = layers.LayerNormalization(epsilon=LN_EPS, name="norm1")
        self.msa = ShiftedWindowMSA(dim, num_heads, window_size, shift_size,
                                    name="sw_msa" if shift_size else "w_msa")
        self.norm2 = layers.LayerNormalization(epsilon=LN_EPS, name="norm2")
        self.mlp = keras.Sequential([
            layers.Dense(int(dim * mlp_ratio), activation="gelu"),
            layers.Dense(dim),
        ], name="mlp")

    def call(self, x):
        x = x + self.msa(self.norm1(x))
        x = x + self.mlp(self.norm2(x))
        return x


class PatchMerging(layers.Layer):
    """Downsample by 2 and double the channel dimension."""

    def __init__(self, dim, **kwargs):
        super().__init__(**kwargs)
        self.norm = layers.LayerNormalization(epsilon=LN_EPS, name="norm")
        self.reduction = layers.Dense(2 * dim, use_bias=False, name="reduction")

    def call(self, x):
        x0 = x[:, 0::2, 0::2, :]
        x1 = x[:, 1::2, 0::2, :]
        x2 = x[:, 0::2, 1::2, :]
        x3 = x[:, 1::2, 1::2, :]
        x = ops.concatenate([x0, x1, x2, x3], axis=-1)
        return self.reduction(self.norm(x))


def swin_backbone(x):
    """Patch partition + linear embedding and the four Swin stages (Table 2)."""
    # Patch Partition + Linear Embedding: Conv2D(128, 4x4, stride 4) -> 64x64x128
    x = layers.Conv2D(EMBED_DIM, kernel_size=PATCH_SIZE, strides=PATCH_SIZE,
                      name="patch_embedding")(x)
    x = layers.LayerNormalization(epsilon=LN_EPS, name="patch_embedding_norm")(x)

    dim = EMBED_DIM
    for stage, (depth, heads) in enumerate(zip(DEPTHS, NUM_HEADS), start=1):
        for b in range(depth):
            # W-MSA followed by SW-MSA (alternating blocks)
            shift = 0 if b % 2 == 0 else WINDOW_SIZE // 2
            x = SwinTransformerBlock(dim, heads, WINDOW_SIZE, shift,
                                     name=f"stage{stage}_block{b + 1}")(x)
        if stage < len(DEPTHS):
            x = PatchMerging(dim, name=f"patch_merging{stage}")(x)
            dim *= 2

    # Stage-4 output: 8 x 8 x 1024 (for a 256 x 256 input)
    x = layers.LayerNormalization(epsilon=LN_EPS, name="backbone_norm")(x)
    return x


# ==============================================================================
# Foreground Feature Enhancement Block (FFEB)
# ==============================================================================
class ImprovedMHSA(layers.Layer):
    """Branch 1 - Improved Multi-Head Self-Attention (Eq. 2-5).

    f = W_f X_m, g = W_g X_m, k = W_k X_m, p = W_p X_m, l = W_l X_m
    beta  = Softmax(f g^T / sqrt(d)),  beta' = Softmax(k p^T / sqrt(d))
    beta^ = Softmax(beta + beta'),     O_m   = beta^ l
    X_MHSA = gamma * Concat(O_1..O_h) + X   (gamma: single learnable scalar)
    """

    def __init__(self, dim, num_heads=FFEB_HEADS, **kwargs):
        super().__init__(**kwargs)
        self.dim = dim
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.scale = self.head_dim ** -0.5
        self.W_f = layers.Dense(dim, name="W_f")
        self.W_g = layers.Dense(dim, name="W_g")
        self.W_k = layers.Dense(dim, name="W_k")
        self.W_p = layers.Dense(dim, name="W_p")
        self.W_l = layers.Dense(dim, name="W_l")

    def build(self, input_shape):
        for proj in (self.W_f, self.W_g, self.W_k, self.W_p, self.W_l):
            proj.build(input_shape)
        self.gamma = self.add_weight(name="gamma", shape=(),
                                     initializer="zeros", trainable=True)

    def _heads(self, t, N):
        t = ops.reshape(t, (-1, N, self.num_heads, self.head_dim))
        return ops.transpose(t, (0, 2, 1, 3))                     # (B, h, N, d)

    def call(self, x):                                             # x: (B, N, C)
        N = x.shape[1]
        f = self._heads(self.W_f(x), N)
        g = self._heads(self.W_g(x), N)
        k = self._heads(self.W_k(x), N)
        p = self._heads(self.W_p(x), N)
        l = self._heads(self.W_l(x), N)

        beta = ops.softmax(ops.matmul(f, ops.transpose(g, (0, 1, 3, 2))) * self.scale, axis=-1)
        beta_r = ops.softmax(ops.matmul(k, ops.transpose(p, (0, 1, 3, 2))) * self.scale, axis=-1)
        beta_hat = ops.softmax(beta + beta_r, axis=-1)

        o = ops.matmul(beta_hat, l)                                # (B, h, N, d)
        o = ops.reshape(ops.transpose(o, (0, 2, 1, 3)), (-1, N, self.dim))
        return self.gamma * o + x


class SWMSABranch(layers.Layer):
    """Branch 2 - Shifted Window-Based Multi-Head Self-Attention on the
    8 x 8 x 1024 Stage-4 map (7 x 7 windows, padding removed after attention,
    cyclic shift of M // 2 and reverse shift)."""

    def __init__(self, dim, num_heads=FFEB_HEADS, window_size=WINDOW_SIZE, **kwargs):
        super().__init__(**kwargs)
        self.norm = layers.LayerNormalization(epsilon=LN_EPS, name="norm")
        self.msa = ShiftedWindowMSA(dim, num_heads, window_size,
                                    shift_size=window_size // 2, name="sw_msa")

    def call(self, x):                                             # x: (B, H, W, C)
        return x + self.msa(self.norm(x))


class GlobalContextBranch(layers.Layer):
    """Branch C - Global Context Refinement (Eq. 7-11).

    X_pool = GAP(X);  K_c = Linear(X_pool), V_c = Linear(X_pool), Q_c = Linear(X)
    Attention_c = Softmax(Q_c K_c^T / sqrt(d))       (single pooled key -> 1)
    X_global = Broadcast(Attention_c . V_c)
    X_global = LayerNorm(X_global + X)
    """

    def __init__(self, dim, **kwargs):
        super().__init__(**kwargs)
        self.dim = dim
        self.scale = dim ** -0.5
        self.q_c = layers.Dense(dim, name="Q_c")
        self.k_c = layers.Dense(dim, name="K_c")
        self.v_c = layers.Dense(dim, name="V_c")
        self.norm = layers.LayerNormalization(epsilon=LN_EPS, name="norm")

    def call(self, x):                                             # x: (B, N, C)
        x_pool = ops.mean(x, axis=1, keepdims=True)                # (B, 1, C)
        q = self.q_c(x)                                            # (B, N, C)
        k = self.k_c(x_pool)                                       # (B, 1, C)
        v = self.v_c(x_pool)                                       # (B, 1, C)
        attn = ops.softmax(ops.matmul(q, ops.transpose(k, (0, 2, 1))) * self.scale, axis=-1)
        x_global = ops.matmul(attn, v)                             # (B, N, C) broadcast
        return self.norm(x_global + x)


def ffeb(x):
    """Foreground Feature Enhancement Block: three parallel branches on the same
    Stage-4 feature map followed by the two-stage fusion (Eq. 12-13)."""
    H, W, C = x.shape[1], x.shape[2], x.shape[3]
    tokens = layers.Reshape((H * W, C), name="ffeb_tokens")(x)     # N x C

    x_mhsa = ImprovedMHSA(C, FFEB_HEADS, name="ffeb_improved_mhsa")(tokens)
    x_sw = SWMSABranch(C, FFEB_HEADS, WINDOW_SIZE, name="ffeb_sw_msa")(x)
    x_sw = layers.Reshape((H * W, C), name="ffeb_sw_msa_tokens")(x_sw)
    x_global = GlobalContextBranch(C, name="ffeb_global_context")(tokens)

    # Stage 1 fusion: F1 = Linear(Concat(X_MHSA, X_SW-MSA))
    f1 = layers.Concatenate(axis=-1, name="ffeb_concat_1")([x_mhsa, x_sw])
    f1 = layers.Dense(C, name="ffeb_fusion_1")(f1)
    # Stage 2 fusion: X_FFEB = Linear(Concat(F1, X_Global))
    x_ffeb = layers.Concatenate(axis=-1, name="ffeb_concat_2")([f1, x_global])
    x_ffeb = layers.Dense(C, name="ffeb_fusion_2")(x_ffeb)

    # token sequence -> 2D map: N x C -> H x W x C
    return layers.Reshape((H, W, C), name="ffeb_to_map")(x_ffeb)


# ==============================================================================
# Multi-Scale Convolution Block (MSCB) - Eq. 14-17
# ==============================================================================
def mscb(x):
    b1 = layers.Conv2D(MSCB_FILTERS, (1, 1), strides=1, padding="same",
                       activation="relu", name="mscb_conv1x1")(x)
    b2 = layers.Conv2D(MSCB_FILTERS, (3, 3), strides=1, padding="same",
                       activation="relu", name="mscb_conv3x3")(x)
    b3 = layers.Conv2D(MSCB_FILTERS, (5, 5), strides=1, padding="same",
                       activation="relu", name="mscb_conv5x5")(x)
    return layers.Concatenate(axis=-1, name="mscb_fusion")([b1, b2, b3])   # H x W x 192


# ==============================================================================
# Channel Attention Module (CAM) - Eq. 18-21
# ==============================================================================
def channel_attention(fusion):
    channels = fusion.shape[-1]                                    # 192
    a = layers.GlobalAveragePooling2D(name="cam_gap")(fusion)      # A_raw
    a = layers.Dense(channels // CA_REDUCTION, activation="relu",
                     name="cam_dense_reduction")(a)                # 192/16 = 12
    a = layers.Dense(channels, activation="sigmoid",
                     name="cam_dense_channels")(a)                 # A_final
    a = layers.Reshape((1, 1, channels), name="cam_reshape")(a)
    return layers.Multiply(name="cam_scale")([fusion, a])          # X_att


# ==============================================================================
# Cosine annealing of the learning rate (Table 1)
# ==============================================================================
class CosineAnnealing(keras.callbacks.Callback):
    """lr_e = 0.5 * lr_0 * (1 + cos(pi * e / E)) over the E epochs of fit()."""

    def __init__(self, base_lr, epochs):
        super().__init__()
        self.base_lr = base_lr
        self.epochs = max(int(epochs), 1)

    def on_epoch_begin(self, epoch, logs=None):
        lr = 0.5 * self.base_lr * (1.0 + math.cos(math.pi * epoch / self.epochs))
        self.model.optimizer.learning_rate.assign(lr)


class FESwinFormer(keras.Model):
    """Functional FESwinFormer model.

    ``fit`` is extended so that (i) the channel-wise Z-score statistics
    (Eq. 1) are computed from the training arrays passed to the first
    ``fit`` call, and (ii) cosine annealing of the learning rate is applied
    over the requested number of epochs. Everything else is standard Keras.
    """

    def fit(self, x=None, y=None, *args, **kwargs):
        norm = self.get_layer("zscore_normalization")
        if not getattr(self, "_zscore_fitted", False) and isinstance(x, np.ndarray):
            norm.set_statistics(*channel_statistics(x))
            self._zscore_fitted = True

        epochs = kwargs.get("epochs", args[1] if len(args) > 1 else 1)
        callbacks = list(kwargs.pop("callbacks", None) or [])
        if not any(isinstance(cb, CosineAnnealing) for cb in callbacks):
            callbacks.append(CosineAnnealing(LEARNING_RATE, epochs))
        return super().fit(x, y, *args, callbacks=callbacks, **kwargs)


# ==============================================================================
# Proposed Model
# ==============================================================================
def create_proposed_model(input_shape, num_classes):
    """Build and compile FESwinFormer.

    input_shape : shape of the stored frames, e.g. (64, 64, 3) for the Kaggle
                  UCF-Crime frames. Frames are resized to 256 x 256 inside the
                  model, as in the paper.
    num_classes : 14 for UCF-Crime (softmax, categorical cross-entropy);
                  1 or 2 for RLVS (single sigmoid unit, binary cross-entropy,
                  labels given as 0/1).
    """
    inputs = layers.Input(shape=input_shape, name="input_frame")

    # Preprocessing: resize to 256 x 256 x 3 and channel-wise Z-score (Eq. 1)
    x = layers.Resizing(IMG_SIZE, IMG_SIZE, interpolation="bilinear",
                        name="resize_256")(inputs)
    x = ChannelZScore(name="zscore_normalization")(x)

    # Hierarchical Swin Transformer backbone -> 8 x 8 x 1024
    x = swin_backbone(x)

    # Foreground Feature Enhancement Block
    x = ffeb(x)

    # Multi-Scale Convolution Block -> H x W x 192
    x = mscb(x)

    # Channel Attention Module
    x = channel_attention(x)

    # Classification Head
    x = layers.GlobalAveragePooling2D(name="head_gap")(x)
    x = layers.Flatten(name="head_flatten")(x)
    x = layers.Dense(DENSE_UNITS, activation="relu", name="head_dense")(x)
    x = layers.Dropout(DROPOUT_RATE, name="head_dropout")(x)

    if num_classes <= 2:        # RLVS: violence / non-violence
        outputs = layers.Dense(1, activation="sigmoid", name="output_sigmoid")(x)
        loss = "binary_crossentropy"
    else:                       # UCF-Crime: 13 anomaly classes + Normal
        outputs = layers.Dense(num_classes, activation="softmax", name="output_softmax")(x)
        loss = "categorical_crossentropy"

    model = FESwinFormer(inputs, outputs, name="FESwinFormer")
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=LEARNING_RATE),
        loss=loss,
        metrics=["accuracy"],
    )
    return model


if __name__ == "__main__":
    model = create_proposed_model((64, 64, 3), 14)
    model.summary()
